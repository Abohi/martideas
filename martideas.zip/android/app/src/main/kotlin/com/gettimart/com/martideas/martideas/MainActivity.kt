package com.gettimart.com.martideas.martideas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
