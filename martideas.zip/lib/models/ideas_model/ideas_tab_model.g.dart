// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ideas_tab_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_IdeasTabModel _$$_IdeasTabModelFromJson(Map<String, dynamic> json) =>
    _$_IdeasTabModel(
      title: json['title'] as String,
      color: json['color'] as int,
    );

Map<String, dynamic> _$$_IdeasTabModelToJson(_$_IdeasTabModel instance) =>
    <String, dynamic>{
      'title': instance.title,
      'color': instance.color,
    };
