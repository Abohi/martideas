// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ideas_like_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_IdeasLikeModel _$$_IdeasLikeModelFromJson(Map<String, dynamic> json) =>
    _$_IdeasLikeModel(
      isLiked: json['isLiked'] as bool,
      userId: json['userId'] as String,
    );

Map<String, dynamic> _$$_IdeasLikeModelToJson(_$_IdeasLikeModel instance) =>
    <String, dynamic>{
      'isLiked': instance.isLiked,
      'userId': instance.userId,
    };
