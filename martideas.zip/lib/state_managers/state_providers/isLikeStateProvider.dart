import 'package:hooks_riverpod/hooks_riverpod.dart';

final isLikedStateProvider = StateProvider<bool>((ref){
  return  false;
});