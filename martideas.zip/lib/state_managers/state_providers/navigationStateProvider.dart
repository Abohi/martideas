import 'package:hooks_riverpod/hooks_riverpod.dart';

final navigationStateProvider = StateProvider<int>((ref){
  return  0;
});