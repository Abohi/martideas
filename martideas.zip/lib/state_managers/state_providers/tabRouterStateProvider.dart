import 'package:auto_route/auto_route.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

final tabRouteStateProvider = StateProvider<TabsRouter?>((ref){
  return  null;
});