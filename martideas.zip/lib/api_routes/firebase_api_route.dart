class FirebaseApiRoute {

  static const String IDEAS_COLLECTION = 'ideas_collection';
  static const String IDEAS_LIKE_COLLECTION = 'likes';
}